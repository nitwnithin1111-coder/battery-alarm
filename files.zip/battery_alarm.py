"""
Battery Alarm
- Plugged in and battery >= HIGH  -> alarm rings (unplug the charger to stop it)
- On battery and battery <= LOW   -> alarm rings (plug in the charger to stop it)
Runs forever in the background. Stop with Ctrl+C or by ending the process.
"""
import platform
import subprocess
import sys
import time

import psutil

HIGH = 80            # ring when charging reaches this %
LOW = 30             # ring when discharging drops to this %
CHECK_EVERY = 20     # seconds between battery checks
RING_EVERY = 8       # seconds between alarm repeats while condition persists

SYSTEM = platform.system()


def notify(title, message):
    """Desktop popup if plyer is installed, otherwise just print."""
    print(f"[{time.strftime('%H:%M:%S')}] {title}: {message}", flush=True)
    try:
        from plyer import notification
        notification.notify(title=title, message=message, timeout=8)
    except Exception:
        pass


def beep():
    """Play a loud, repeated alarm sound."""
    try:
        if SYSTEM == "Windows":
            import winsound
            for _ in range(3):
                winsound.Beep(1500, 400)
                winsound.Beep(1000, 400)
        elif SYSTEM == "Darwin":
            for _ in range(3):
                subprocess.run(["afplay", "/System/Library/Sounds/Sosumi.aiff"])
        else:
            for _ in range(3):
                subprocess.run(["paplay", "/usr/share/sounds/freedesktop/stereo/alarm-clock-elapsed.oga"])
    except Exception:
        for _ in range(3):
            sys.stdout.write("\a")
            sys.stdout.flush()
            time.sleep(0.4)


def main():
    if psutil.sensors_battery() is None:
        print("No battery detected. This script is for laptops.")
        return

    print(f"Battery alarm running. High alert: {HIGH}%, low alert: {LOW}%")
    last_ring = 0.0

    while True:
        b = psutil.sensors_battery()
        percent, plugged = b.percent, b.power_plugged
        now = time.time()

        if plugged and percent >= HIGH:
            if now - last_ring >= RING_EVERY:
                notify("Battery full enough", f"{percent:.0f}% - unplug the charger")
                beep()
                last_ring = now
            time.sleep(2)
            continue

        if not plugged and percent <= LOW:
            if now - last_ring >= RING_EVERY:
                notify("Battery low", f"{percent:.0f}% - plug in the charger")
                beep()
                last_ring = now
            time.sleep(2)
            continue

        time.sleep(CHECK_EVERY)


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\nStopped.")

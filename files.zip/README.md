# Battery Alarm

Rings an alarm when your laptop battery reaches **80% while charging** (unplug it) and when it drops to **30% on battery** (plug it in). Keeps ringing until you act.

## Setup
```
pip install -r requirements.txt
python battery_alarm.py
```
Change `HIGH` and `LOW` at the top of `battery_alarm.py` to use other percentages.

## Run 24/7 automatically (Windows)
1. Press `Win + R`, type `shell:startup`, press Enter.
2. Right-click in that folder > New > Shortcut.
3. Target: `pythonw "C:\full\path\to\battery_alarm.py"`
   (`pythonw` runs it with no console window.)
4. It now starts every time you log in. To stop it: Task Manager > end `pythonw.exe`.

## Run 24/7 automatically (macOS)
Create `~/Library/LaunchAgents/com.batteryalarm.plist` that runs `python3 /path/to/battery_alarm.py` with `RunAtLoad` and `KeepAlive` set to true, then run `launchctl load` on it.

## Run 24/7 automatically (Linux)
Add `python3 /path/to/battery_alarm.py &` to your startup applications, or make a systemd user service.

## Put it on GitHub
```
git init
git add .
git commit -m "Battery alarm"
git branch -M main
git remote add origin https://github.com/YOUR-USERNAME/battery-alarm.git
git push -u origin main
```
Create the empty `battery-alarm` repository on github.com first.

Note: GitHub only stores the code. The script must run on your own laptop, because only your laptop can read its battery.
